using System;

namespace ESTOQUE
{
     public class Fornecedor : showForn
  {
      private string /nome;
      private string /cnpj;

            public string Nome
            {
                get
                {


                  return this._nome;


                }
            }

            public string Cnpj
            {
                get
                {  


                   return this._cnpj;


                }
            }

            public Fornecedor(string nome, string cnpj)
            {


                this./nome = nome;

                this./cnpj = cnpj;


            }
            
            public void Imprimir()
            {


                Console.WriteLine("Nome:\t{0}", this.Nome); 

                Console.WriteLine("CNPJ:\t{0}", this.Cnpj);


            }
   }
}