using System;
using System.Collections.Generic;

namespace ESTOQUE
{
    class Program
    {
           public static void Main(string[] args)
          {                 
                bool MostrarMenu = true;
                while (MostrarMenu)
                {
                    MostrarMenu = MenuPrincipal();
                }
          }
          private static bool MenuPrincipal()
            {

                Console.Clear();
                Console.WriteLine("2 - Atividade 1 e 2");
                  Console.WriteLine("3 - Atividade);
                    Console.WriteLine("4 - Quarta atividade");
                      Console.WriteLine("5 - Quinta atividade");
                        Console.WriteLine("6 - Script primário");
                          Console.WriteLine("7 - Fechar");
 
                if (Console.ReadLine() = 2)
                {
                  Console.Clear();
                           
                      Fornecedor Fornecedor_ = new Fornecedor( "João Dória", "45.696.940/0001-03");
                            
                      Produto ProdutoFisico = new ProdutoFisico("Mausi Michaelsóft", 89.90, 12.99, Fornecedor_);                     
                      ProdutoFisico.Imprimir();    

                  Console.WriteLine("Saia com qualquer botão!");
                  Console.ReadKey();
                }
                            
                if (Console.ReadLine() = 3)
                {  
                  Console.Clear();
                           
        
                  Licensa Peixe_Frito = new Licensa("Peixe Frito", 2999.90, "XZLT-CXL9-SLHV-99UM");
                  Estoque  Estoque_ = new Estoque();
                        
                  for(int i = 0; i < 5; i++)
                  {

                      Estoque_.Adicionar(Peixe_Frito);

                  }
                    
                  for(int i = 0; i < 3; i++)
                  {

                      Estoque_.Remover(Peixe_Frito);

                  }
                        
                     
                  Estoque_.ImprimirEstoque();
                            
                  Console.WriteLine("Pressione qualtquer tecla para sair");
                  Console.ReadKey();
                }         


                  for(int i = 0; i < 5; i++)
                  {

                  Estoque_3.Adicionar(Peixe_Frito_2);
                  Estoque_3.Adicionar(MudaPauBrasil);

                  }

                   if (Console.ReadLine() = 5 )
                   {
                    Console.Clear();

                    Fornecedor Fornecedor_02 = new Fornecedor("Fornecedor 02", );
                    Fornecedor Fornecedor_03 = new Fornecedor("Fornecedor 03", );
                
                    Relatorio relatorioFornecedores_ = new Relatorio

                            );
                            
                    relatorioFornecedores_.AdicionarItem(Fornecedor_02);
                    relatorioFornecedores_.AdicionarItem(Fornecedor_03);
                    relatorioFornecedores_.ImprimirRelatorio();
                       
                    Licensa Software_02 = new Licensa("Software 02", 300.90, ");
                    Licensa Software_03 = new Licensa("Software 03", 300.90, ");

                    Relatorio relatorioLicencas = new Relatorio(
                            );

                            relatorioLicencas.AdicionarItem(Software_02);
                              relatorioLicencas.AdicionarItem(Software_03);
                              relatorioLicencas.ImprimirRelatorio();
                              Console.WriteLine("Pressione qualtquer tecla para sair");
                             Console.ReadKey();
                   }

                   if (Console.ReadLine() = 6) 
                   {

                    Console.Clear();                  
                    Licensa pellto = new Licensa(" Pellto", 90.00);
                            
                          Assinatura Kampaign = new Assinatura("Kampaign", 17.50,);
                            
                              Assinatura corehul =
                                      new Assinatura("Mwitter", mensalidade: 35.00);
                              Assinatura cottonshopi =
                                        new Assinatura("CakeNook", mensalidade: 23.80);
                              Assinatura premillere =
                                          new Assinatura("YouBug", mensalidade: 55.50 );

                         Fornecedor Fornecedor_4 = new Fornecedor(nome: "Nygor Nacalli", cnpj: "46.879.555-09");
                      
                   }        
                   
                  if (Console.ReadLine() = 7)
                  {

                    Environment.Exit(0);

                  }

                }

            }









    }
}