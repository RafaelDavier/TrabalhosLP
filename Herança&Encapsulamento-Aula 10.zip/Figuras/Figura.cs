namespace herançaEncaps
{
  //Determina as condições da figura
    public class Figura
    {
        protected double fArea;
        protected double fPerimetro; 
        protected string nome;

        public double Perimetro 


        {  
          get { return this.fPerimetro; }  



          
          }

          public double Area 
        {  


          get { return this.fArea; }   


          
          }      

          public string Nome        
        {


           get { return this.fnome; }
           


            }
        
        

